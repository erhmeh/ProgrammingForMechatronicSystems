var searchData=
[
  ['takereading',['takeReading',['../classRanger.html#af3c38e14a1cec55729563b5feebf1e6f',1,'Ranger']]]
];
