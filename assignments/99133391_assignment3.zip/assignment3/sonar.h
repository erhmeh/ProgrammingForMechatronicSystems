/**
 * sonar.h
 * Programming for Mechatronic systems
 * Assignment 3
 *
 * @author: Jamin Early 99133391
 * @date: Week 8 Autumn Semester 2018
 */

#ifndef SONAR_H
#define SONAR_H

#include "ranger.h"

class Sonar : public Ranger
{
public:
	Sonar();
};

#endif /** RADAR_H */
